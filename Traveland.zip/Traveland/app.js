const rightcard2 = document.querySelector('.bg2')
const rightcard3 = document.querySelector('.bg3')
const rightcard4 = document.querySelector('.bg4')
const righttext1 = document.querySelector('.one')
const righttext2 = document.querySelector('.two')
const righttext3 = document.querySelector('.three')
rightcard2.addEventListener("mouseover",overfunc)
rightcard2.addEventListener("mouseout",outfunc)
rightcard3.addEventListener("mouseover",overfunc2)
rightcard3.addEventListener("mouseout",outfunc2)
rightcard4.addEventListener("mouseover",overfunc3)
rightcard4.addEventListener("mouseout",outfunc3)
function overfunc(){
    rightcard2.style.transform = 'scale(1.05)'
    righttext1.style.transform = 'scale(1.05)'
}
function outfunc(){
    rightcard2.style.transform = 'scale(1)'
    righttext1.style.transform = 'scale(1)'
}
function overfunc2(){
    rightcard3.style.transform = 'scale(1.05)'
    righttext2.style.transform = 'scale(1.05)'
}
function outfunc2(){
    rightcard3.style.transform = 'scale(1)'
    righttext2.style.transform = 'scale(1)'
}
function overfunc3(){
    rightcard4.style.transform = 'scale(1.05)'
    righttext3.style.transform = 'scale(1.05)'
}
function outfunc3(){
    rightcard4.style.transform = 'scale(1)'
    righttext3.style.transform = 'scale(1)'
}